# projects
For the first time clone the repo:

git clone https://git.txstate.edu/CS3354/projects.git



To pull any updates go to projects folder on your local computer and open git bash. Then run the following command:

git pull
